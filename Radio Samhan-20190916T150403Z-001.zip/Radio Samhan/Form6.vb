﻿Imports MySql.Data.MySqlClient
Imports System.Data.SqlClient
Imports System.Data

Public Class form6
    Dim koneksi As MySqlConnection
    Dim sql, username, password As String
    Dim cmd, cmd2, cmd3, cm4 As MySqlCommand
    Dim rd, rd2, rd3, rd4 As MySqlDataReader
    Sub nama()
        cmd = New MySqlCommand("select * from riwayat order by id DESC", konek)
        rd = cmd.ExecuteReader
        If rd.Read Then
            TextBox1.Text = rd.Item("username")
            rd.Close()
        End If
    End Sub
    Sub hapus()
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
    End Sub
    Private Sub form6_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        konek()
        nama()
        cmd2 = New MySqlCommand("select password from login where username = '" & TextBox1.Text & "' ", konek)
        rd2 = cmd2.ExecuteReader
        If rd2.Read Then
            TextBox4.Text = rd2.Item("password")
            rd2.Close()
        End If
        rd.Close()
        hapus()
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox2.Text = "" Or TextBox3.Text = "" Then
            MsgBox("ISI DATA TERLEBIH DAHULU")
        Else
            Dim user, password As String
            password = TextBox2.Text
            user = TextBox1.Text
            sql = "Select * from login where password ='" + password + "' and username ='" + user + "'"
            cmd2 = New MySqlCommand(sql, konek)
            rd2 = cmd2.ExecuteReader
            rd2.Read()
            If rd2.HasRows Then
                Dim cmd3 As MySqlCommand
                Dim Sqltambahan As String = "UPDATE login SET password ='" & TextBox3.Text & "' where username = '" + user + "'"
                cmd3 = New MySqlCommand(Sqltambahan, konek)
                cmd3.ExecuteNonQuery()
                MsgBox("DATA BERHASIL DI UBAH")
                Me.Close()
                hapus()
            Else
                MsgBox("Password yang anda masukan salah")
                TextBox2.Focus()
            End If
        End If
    End Sub
    Private Sub Form2_Load_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        konek()
        nama()
    End Sub
    Private Sub PictureBox3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox3.Click
        Me.Close()
        menuUser.Show()
    End Sub

    Private Sub KARYAWANToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KARYAWANToolStripMenuItem.Click
        Me.Close()
        statusstaff.Show()
    End Sub

    Private Sub GAJIPENYIARToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GAJIPENYIARToolStripMenuItem.Click
        Me.Close()
        Form4.Show()
    End Sub

    Private Sub EDITAKUNToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EDITAKUNToolStripMenuItem1.Click
        Me.Show()
    End Sub

    Private Sub GAJISTAFFToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GAJISTAFFToolStripMenuItem.Click
        Me.Close()
        Form5.Show()
    End Sub
End Class