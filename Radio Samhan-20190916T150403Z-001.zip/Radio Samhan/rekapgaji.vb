﻿Imports MySql.Data.MySqlClient
Imports System.Data.SqlClient
Imports System.Data

Public Class rekapgaji

    Dim koneksi As MySqlConnection
    Dim sql, username, password As String
    Dim cmd, cmd2 As MySqlCommand
    Dim rd, rd2 As MySqlDataReader


    Sub atur()
        Me.DataGridView1.Columns(0).HeaderText = "ID"
        Me.DataGridView1.Columns(1).HeaderText = "BULAN"
        Me.DataGridView1.Columns(2).HeaderText = "NAMA PENYIAR"
        Me.DataGridView1.Columns(3).HeaderText = "TOTAL GAJI"
        Me.DataGridView1.Columns(0).Width = 100
        Me.DataGridView1.Columns(2).Width = 200
        Me.DataGridView1.Columns(1).Width = 200
        Me.DataGridView1.Columns(3).Width = 200
    End Sub

    Sub atur2()
        Me.DataGridView1.Columns(0).HeaderText = "BULAN"
        Me.DataGridView1.Columns(1).HeaderText = "NAMA PENYIAR"
        Me.DataGridView1.Columns(2).HeaderText = "TOTAL GAJI"
        Me.DataGridView1.Columns(0).Width = 100
        Me.DataGridView1.Columns(2).Width = 300
        Me.DataGridView1.Columns(1).Width = 300
    End Sub

    Sub tableabsen()
        Dim myadapter As New MySqlDataAdapter("select * from absen_penyiar", konek)
        Dim mydata As New DataTable
        myadapter.Fill(mydata)
        DataGridView2.DataSource = mydata
    End Sub

    Sub gaji()
        Dim myadapter3 As New MySqlDataAdapter("select * from rekap_gaji where nama_penyiar = '" & ComboBox2.Text & "' and bulan= '" & TextBox6.Text & "' ORDER BY nama_penyiar DESC LIMIT 1 ", konek)
        Dim mydata3 As New DataTable
        myadapter3.Fill(mydata3)
        DataGridView1.DataSource = mydata3
    End Sub

    Private Sub rekapgaji_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim myadapter3 As New MySqlDataAdapter("select * from rekap_gaji where bulan= '" & TextBox6.Text & "' ORDER BY nama_penyiar DESC LIMIT 1 ", konek)
        Dim mydata3 As New DataTable
        myadapter3.Fill(mydata3)
        DataGridView1.DataSource = mydata3

        Dim cmd, cmd2 As New MySqlCommand
        Dim rdr As MySqlDataReader

        cmd = New MySqlCommand("select distinct nama_penyiar FROM absen_penyiar ", konek)
        rdr = cmd.ExecuteReader
        While rdr.Read
            ComboBox2.Items.Add(rdr.Item(0))
        End While
        tableabsen()
        konek()
    End Sub


    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim bulan As String
        bulan = ComboBox1.Text
        Select Case bulan
            Case "Januari"
                TextBox1.Text = "01"
                TextBox6.Text = "Januari"
            Case "Februari"
                TextBox1.Text = "02"
                TextBox6.Text = "Februari"
            Case "Maret"
                TextBox1.Text = "03"
                TextBox6.Text = "Maret"
            Case "April"
                TextBox1.Text = "04"
                TextBox6.Text = "April"
            Case "Mei"
                TextBox1.Text = "05"
                TextBox6.Text = "Mei"
            Case "Juni"
                TextBox1.Text = "06"
                TextBox6.Text = "Juni"
            Case "Juli"
                TextBox1.Text = "07"
                TextBox6.Text = "Juli"
            Case "Agustus"
                TextBox1.Text = "08"
                TextBox6.Text = "Agustus"
            Case "September"
                TextBox1.Text = "09"
                TextBox6.Text = "September"
            Case "Oktober"
                TextBox1.Text = "10"
                TextBox6.Text = "Oktober"
            Case "November"
                TextBox1.Text = "11"
                TextBox6.Text = "November"
            Case "Desember"
                TextBox1.Text = "12"
                TextBox6.Text = "Desember"
        End Select
        If ComboBox2.Text = "semua" Then
            Dim myadapter1 As New MySqlDataAdapter("select distinct bulan,nama_penyiar,gaji from rekap_gaji where bulan= '" & TextBox6.Text & "' ", konek)
            Dim mydata1 As New DataTable
            myadapter1.Fill(mydata1)
            DataGridView1.DataSource = mydata1
            atur2()
        Else
            Dim myadapter As New MySqlDataAdapter("select * from absen_penyiar where nama_penyiar = '" & ComboBox2.Text & "' and tanggal LIKE '%-" & TextBox1.Text & "-%' ", konek)
            Dim mydata As New DataTable
            myadapter.Fill(mydata)
            DataGridView2.DataSource = mydata

            Dim hitung As Integer
            For baris As Integer = 0 To DataGridView2.RowCount - 1
                hitung = hitung + DataGridView2.Rows(baris).Cells(4).Value
            Next
            TextBox2.Text = hitung
            TextBox3.Text = DataGridView2.RowCount - 1

            Dim transport, siaran As Integer
            siaran = Val(TextBox2.Text) * 20000
            transport = Val(TextBox3.Text) * 30000
            TextBox4.Text = siaran + transport

            Dim Sqltambah As String = "INSERT INTO rekap_gaji(bulan,nama_penyiar,gaji)values ('" & TextBox6.Text & "','" & ComboBox2.Text & "','" & TextBox4.Text & "')"
            cmd = New MySqlCommand(Sqltambah, konek)
            cmd.ExecuteNonQuery()

            cmd = New MySqlCommand("UPDATE rekap_gaji SET gaji = '" & TextBox4.Text & "' where nama_penyiar = '" & ComboBox2.Text & "'", konek)
            cmd.ExecuteNonQuery()
            gaji()
            atur()
        End If
    End Sub

    Private Sub PictureBox3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox3.Click
        Me.Close()
    End Sub

    Private Sub GAJIPENYIARToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GAJIPENYIARToolStripMenuItem.Click
        Me.Show()
    End Sub

    Private Sub GAJISTAFFToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GAJISTAFFToolStripMenuItem.Click
        Me.Close()
        gajistaff.Show()
    End Sub

    Private Sub SIARANToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SIARANToolStripMenuItem.Click
        Me.Close()
        editJS.Show()
    End Sub

    Private Sub LEMBURToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LEMBURToolStripMenuItem.Click
        Me.Close()
        editJL.Show()
    End Sub

    Private Sub PENYIARToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PENYIARToolStripMenuItem1.Click
        Me.Close()
        editpenyiar.Show()
    End Sub

    Private Sub KARYAWANToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KARYAWANToolStripMenuItem.Click
        Me.Close()
        editstaff.Show()
    End Sub

    Private Sub PENYIARToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PENYIARToolStripMenuItem.Click
        Me.Close()
        absenpenyiar.Show()
    End Sub

    Private Sub STAFToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles STAFToolStripMenuItem.Click
        Me.Close()
        absenstaff.Show()
    End Sub
End Class