﻿Imports MySql.Data.MySqlClient
Imports System.Data.SqlClient
Imports System.Data
Public Class menuUser

    Sub nama()
        Dim cmd, cmd2, cmd3, cmd4 As New MySqlCommand
        Dim rd, rd2, rd3, rd4 As MySqlDataReader
        cmd = New MySqlCommand("select * from riwayat order by id DESC", konek)
        rd = cmd.ExecuteReader
        If rd.Read Then
            TextBox1.Text = rd.Item("username")
            rd.Close()
        End If
        cmd4 = New MySqlCommand("select * from dua where username = '" & TextBox1.Text & "' ", konek)
        rd4 = cmd4.ExecuteReader
        cmd2 = New MySqlCommand("select * from penyiar where username = '" & TextBox1.Text & "' ", konek)
        rd2 = cmd2.ExecuteReader
        cmd3 = New MySqlCommand("select * from karyawan where username = '" & TextBox1.Text & "' ", konek)
        rd3 = cmd3.ExecuteReader
        
        If rd4.Read Then
            STAFToolStripMenuItem.Enabled = True
            PENYIARToolStripMenuItem.Enabled = True
        ElseIf rd2.Read Then
            STAFToolStripMenuItem.Enabled = False
            GAJIKARYAWANToolStripMenuItem.Enabled = False
        Else
            PENYIARToolStripMenuItem.Enabled = False
            GAJIPENYIARToolStripMenuItem.Enabled = False
        End If
        rd.Close()
    End Sub

    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        MsgBox("ANDA YAKIN INGIN KELUAR?")
        Me.Close()
        login.Show()
    End Sub

    Private Sub menuUser_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        konek()
        nama()
    End Sub

    Private Sub Label4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub PENYIARToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PENYIARToolStripMenuItem.Click
        Me.Close()
        AP.Show()
    End Sub

    Private Sub SIARANToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SIARANToolStripMenuItem.Click
        Me.Close()
        JS.Show()
    End Sub

    Private Sub LEMBURToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LEMBURToolStripMenuItem.Click
        Me.Close()
        JL.Show()
    End Sub

    Private Sub EDITAKUNToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Close()
        editakun.Show()
    End Sub

    Private Sub STAFToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles STAFToolStripMenuItem.Click
        Me.Close()
        Form1.Show()
    End Sub

    Private Sub PictureBox1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox1.Click
        MsgBox("ANDA YAKIN INGIN KELUAR??")
        Me.Close()
        login.Show()
    End Sub

    Private Sub EDITAKUNToolStripMenuItem_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EDITAKUNToolStripMenuItem.Click
        Me.Close()
        editakun.Show()
    End Sub

    Private Sub GAJIPENYIARToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GAJIPENYIARToolStripMenuItem.Click
        Me.Close()
        Form2.Show()
    End Sub

    Private Sub GAJIKARYAWANToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GAJIKARYAWANToolStripMenuItem.Click
        Me.Close()
        Form3.Show()
    End Sub
End Class