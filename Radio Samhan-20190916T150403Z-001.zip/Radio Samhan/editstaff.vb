﻿Imports MySql.Data.MySqlClient
Imports System.Data.SqlClient
Imports System.Data

Public Class editstaff

    Sub opentable()
        Dim myadapter As New MySqlDataAdapter("select * from karyawan", konek)
        Dim mydata As New DataTable
        myadapter.Fill(mydata)
        DataGridView1.DataSource = mydata
    End Sub

    Sub apus()
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""
        TextBox7.Text = ""
        TextBox4.Text = ""
        TextBox10.Text = ""
        DateTimePicker1.Format = DateTimePickerFormat.Custom
        DateTimePicker1.CustomFormat = "d/MMMM/yyyy"
        DateTimePicker3.Format = DateTimePickerFormat.Custom
        DateTimePicker3.CustomFormat = "d/MMMM/yyyy"
        RadioButton1.Checked = False
        RadioButton2.Checked = False
    End Sub

    Sub atur()
        Me.DataGridView1.Columns(0).HeaderText = "ID"
        Me.DataGridView1.Columns(1).HeaderText = "TANGGAL BEKERJA"
        Me.DataGridView1.Columns(2).HeaderText = "NAMA LENGKAP"
        Me.DataGridView1.Columns(3).HeaderText = "TEMPAT LAHIR"
        Me.DataGridView1.Columns(4).HeaderText = "TANGGAL LAHIR"
        Me.DataGridView1.Columns(5).HeaderText = "JENIS KELAMIN"
        Me.DataGridView1.Columns(6).HeaderText = "AGAMA"
        Me.DataGridView1.Columns(7).HeaderText = "ALAMAT LENGKAP"
        Me.DataGridView1.Columns(8).HeaderText = "NO HANDPHONE"
        Me.DataGridView1.Columns(9).HeaderText = "EMAIL"
        Me.DataGridView1.Columns(10).HeaderText = "USERNAME"
        Me.DataGridView1.Columns(11).HeaderText = "JABATAN"
        Me.DataGridView1.Columns(12).HeaderText = "STATUS"
        Me.DataGridView1.Columns(13).HeaderText = "JENIS JABATAN"
        Me.DataGridView1.Columns(1).Width = 100
        Me.DataGridView1.Columns(2).Width = 100
        Me.DataGridView1.Columns(3).Width = 100
        Me.DataGridView1.Columns(4).Width = 100
        Me.DataGridView1.Columns(0).Width = 50
        Me.DataGridView1.Columns(5).Width = 100
        Me.DataGridView1.Columns(6).Width = 100
        Me.DataGridView1.Columns(7).Width = 100
        Me.DataGridView1.Columns(8).Width = 100
        Me.DataGridView1.Columns(9).Width = 100
        Me.DataGridView1.Columns(10).Width = 100
        Me.DataGridView1.Columns(11).Width = 100
        Me.DataGridView1.Columns(12).Width = 100
        Me.DataGridView1.Columns(13).Width = 100
    End Sub


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Or TextBox5.Text = "" Or TextBox10.Text = "" Or TextBox6.Text = "" Or TextBox7.Text = "" Or TextBox8.Text = "" Or TextBox9.Text = "" Then
            MsgBox("ISI DATA DENGAN LENGKAP !")
        Else
            Dim jk As String
            If RadioButton1.Checked Then
                jk = "L"
            Else
                jk = "P"
            End If
            Dim cmd, cmd2 As MySqlCommand
            Dim Sqltambahan As String = "INSERT INTO karyawan(id_karyawan,tgl_kerja,nama_karyawan,tempat_lahir, tgl_lahir,jk,agama,alamat,no_hp,email,username,jabatan,status,jenis_jbt)values ('" & TextBox5.Text & "','" & Format(DateTimePicker1.Value, "d-MMMM-yyyy") & "','" & TextBox1.Text & "','" & TextBox2.Text & "','" & Format(DateTimePicker3.Value, "d-MMMM-yyyy") & "','" & jk & "','" & ComboBox1.Text & "','" & TextBox7.Text & "','" & TextBox6.Text & "','" & TextBox9.Text & "','" & TextBox8.Text & "', '" & TextBox3.Text & "', '" & TextBox4.Text & "', '" & TextBox10.Text & "')"
            cmd = New MySqlCommand(Sqltambahan, konek)
            cmd.ExecuteNonQuery()
            Dim Sql As String = "INSERT INTO login(username,password)values ('" & TextBox8.Text & "','" & TextBox6.Text & "')"
            cmd2 = New MySqlCommand(Sql, konek)
            cmd2.ExecuteNonQuery()
            MsgBox("DATA BERHASIL DITAMBAHKAN")
            opentable()
            apus()
        End If
    End Sub

    Private Sub editpenyiar_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        opentable()
        konek()
        atur()
        apus()
    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        DateTimePicker1.Value = DataGridView1.Rows(e.RowIndex).Cells(1).Value
        DateTimePicker3.Value = DataGridView1.Rows(e.RowIndex).Cells(4).Value
        TextBox5.Text = DataGridView1.Rows(e.RowIndex).Cells(0).Value
        TextBox1.Text = DataGridView1.Rows(e.RowIndex).Cells(2).Value
        TextBox2.Text = DataGridView1.Rows(e.RowIndex).Cells(3).Value
        If DataGridView1.Rows(e.RowIndex).Cells(5).Value = "L" Then
            RadioButton1.Checked = True
        Else
            RadioButton2.Checked = True
        End If
        ComboBox1.Text = DataGridView1.Rows(e.RowIndex).Cells(6).Value
        TextBox7.Text = DataGridView1.Rows(e.RowIndex).Cells(7).Value
        TextBox6.Text = DataGridView1.Rows(e.RowIndex).Cells(8).Value
        TextBox9.Text = DataGridView1.Rows(e.RowIndex).Cells(9).Value
        TextBox8.Text = DataGridView1.Rows(e.RowIndex).Cells(10).Value
        TextBox3.Text = DataGridView1.Rows(e.RowIndex).Cells(11).Value
        TextBox4.Text = DataGridView1.Rows(e.RowIndex).Cells(12).Value
        TextBox10.Text = DataGridView1.Rows(e.RowIndex).Cells(13).Value
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Or TextBox5.Text = "" Or TextBox10.Text = "" Or TextBox6.Text = "" Or TextBox7.Text = "" Or TextBox8.Text = "" Or TextBox9.Text = "" Then
            MsgBox("DATA BELUM LENGKAP")
        Else
            Dim jk As String
            If RadioButton1.Checked Then
                jk = "L"
            Else
                jk = "P"
            End If
            Dim cmd5 As MySqlCommand
            cmd5 = New MySqlCommand(" UPDATE karyawan SET nama_karyawan ='" & TextBox1.Text & "', tempat_lahir = '" & TextBox2.Text & "', tgl_lahir='" & Format(DateTimePicker3.Value, "d-MMMM-yyyy") & "', jk = '" & jk & "', agama = '" & ComboBox1.Text & "', alamat ='" & TextBox7.Text & "', no_hp = '" & TextBox6.Text & "', email = '" & TextBox9.Text & "', username = '" & TextBox8.Text & "', jabatan = '" & TextBox3.Text & "' , status = '" & TextBox4.Text & "', jenis_jbt = '" & TextBox10.Text & "' WHERE id_karyawan = '" & TextBox5.Text & "'", konek)
            cmd5.ExecuteNonQuery()
            MsgBox("Data Berhasil Disimpan")
            opentable()
            apus()
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim cmd2 As MySqlCommand
        cmd2 = New MySqlCommand("DELETE FROM karyawan where id_karyawan = '" & TextBox5.Text & "' ", konek)
        cmd2.ExecuteNonQuery()
        MsgBox("Yakin ingin hapus data?")
        MsgBox("DATA BERHASIL TERHAPUS")
        opentable()
        apus()
    End Sub

    Private Sub SIARANToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SIARANToolStripMenuItem.Click
        Me.Show()
        editJS.Show()
    End Sub

    Private Sub LEMBURToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LEMBURToolStripMenuItem.Click
        Me.Close()
        editJL.Show()
    End Sub

    Private Sub PENYIARToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PENYIARToolStripMenuItem1.Click
        Me.Show()
        editpenyiar.Show()
    End Sub

    Private Sub KARYAWANToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KARYAWANToolStripMenuItem.Click
        Me.Show()
    End Sub

    Private Sub PENYIARToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PENYIARToolStripMenuItem.Click
        Me.Close()
        absenpenyiar.Show()
    End Sub

    Private Sub STAFToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles STAFToolStripMenuItem.Click
        Me.Close()
        absenstaff.Show()
    End Sub

    Private Sub PENGGAJIANToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PENGGAJIANToolStripMenuItem.Click
        Me.Close()
        rekapgaji.Show()
    End Sub

    Private Sub DataGridView1_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles DataGridView1.CellMouseClick
        DateTimePicker1.Value = DataGridView1.Rows(e.RowIndex).Cells(1).Value
        DateTimePicker3.Value = DataGridView1.Rows(e.RowIndex).Cells(4).Value
        TextBox5.Text = DataGridView1.Rows(e.RowIndex).Cells(0).Value
        TextBox1.Text = DataGridView1.Rows(e.RowIndex).Cells(2).Value
        TextBox2.Text = DataGridView1.Rows(e.RowIndex).Cells(3).Value
        If DataGridView1.Rows(e.RowIndex).Cells(5).Value = "L" Then
            RadioButton1.Checked = True
        Else
            RadioButton2.Checked = True
        End If
        ComboBox1.Text = DataGridView1.Rows(e.RowIndex).Cells(6).Value
        TextBox7.Text = DataGridView1.Rows(e.RowIndex).Cells(7).Value
        TextBox6.Text = DataGridView1.Rows(e.RowIndex).Cells(8).Value
        TextBox9.Text = DataGridView1.Rows(e.RowIndex).Cells(9).Value
        TextBox8.Text = DataGridView1.Rows(e.RowIndex).Cells(10).Value
        TextBox3.Text = DataGridView1.Rows(e.RowIndex).Cells(11).Value
        TextBox4.Text = DataGridView1.Rows(e.RowIndex).Cells(12).Value
        TextBox10.Text = DataGridView1.Rows(e.RowIndex).Cells(13).Value
    End Sub

    Private Sub PictureBox3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox3.Click
        Me.Hide()
        menuAdmin.Show()
    End Sub
End Class