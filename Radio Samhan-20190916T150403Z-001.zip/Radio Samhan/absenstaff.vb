﻿Imports MySql.Data.MySqlClient
Imports System.Data.SqlClient
Imports System.Data

Public Class absenstaff

    Sub opentable()
        Dim myadapter As New MySqlDataAdapter("select * from absen_karyawan", konek)
        Dim mydata As New DataTable
        myadapter.Fill(mydata)
        DataGridView1.DataSource = mydata
    End Sub

    Sub atur()
        Me.DataGridView1.Columns(0).HeaderText = "HARI SIARAN"
        Me.DataGridView1.Columns(1).HeaderText = "WAKTU SIARAN"
        Me.DataGridView1.Columns(2).HeaderText = "NAMA ACARA"
        Me.DataGridView1.Columns(3).HeaderText = "NAMA PENYIAR"
        Me.DataGridView1.Columns(1).Width = 200
        Me.DataGridView1.Columns(2).Width = 200
        Me.DataGridView1.Columns(3).Width = 200
        Me.DataGridView1.Columns(0).Width = 200

    End Sub

    Private Sub absenstaff_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        opentable()
        konek()
        atur()
    End Sub

    Private Sub SIARANToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SIARANToolStripMenuItem.Click
        Me.Show()
        editJS.Show()
    End Sub

    Private Sub LEMBURToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LEMBURToolStripMenuItem.Click
        Me.Close()
        editJL.show()
    End Sub

    Private Sub PENYIARToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PENYIARToolStripMenuItem1.Click
        Me.Show()
    End Sub

    Private Sub KARYAWANToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KARYAWANToolStripMenuItem.Click
        Me.Close()
        editstaff.show()
    End Sub

    Private Sub PENYIARToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PENYIARToolStripMenuItem.Click
        Me.Close()
        absenpenyiar.Show()
    End Sub

    Private Sub STAFToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles STAFToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub GAJIToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GAJIToolStripMenuItem.Click
        Me.Close()
        rekapgaji.Show()
    End Sub

    Private Sub GAJISTAFFToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GAJISTAFFToolStripMenuItem.Click
        Me.Close()
        gajistaff.Show()
    End Sub
End Class