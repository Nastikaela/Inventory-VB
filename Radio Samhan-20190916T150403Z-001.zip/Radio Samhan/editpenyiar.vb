﻿Imports MySql.Data.MySqlClient
Imports System.Data.SqlClient
Imports System.Data

Public Class editpenyiar

    Sub opentable()
        Dim myadapter As New MySqlDataAdapter("select * from penyiar", konek)
        Dim mydata As New DataTable
        myadapter.Fill(mydata)
        DataGridView1.DataSource = mydata
    End Sub

    Sub apus()
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""
        TextBox7.Text = ""
        TextBox8.Text = ""
        TextBox9.Text = ""
        RadioButton1.Checked = False
        RadioButton2.Checked = False
    End Sub

    Sub atur()
        Me.DataGridView1.Columns(0).HeaderText = "ID"
        Me.DataGridView1.Columns(1).HeaderText = "NAMA PENYIAR"
        Me.DataGridView1.Columns(2).HeaderText = "TEMPAT TANGGAL LAHIR"
        Me.DataGridView1.Columns(3).HeaderText = "JENIS KELAMIN"
        Me.DataGridView1.Columns(4).HeaderText = "AGAMA"
        Me.DataGridView1.Columns(5).HeaderText = "ALAMAT"
        Me.DataGridView1.Columns(6).HeaderText = "NO HANDPHONE"
        Me.DataGridView1.Columns(7).HeaderText = "EMAIL"
        Me.DataGridView1.Columns(8).HeaderText = "USERNAME"
        Me.DataGridView1.Columns(1).Width = 100
        Me.DataGridView1.Columns(2).Width = 100
        Me.DataGridView1.Columns(3).Width = 100
        Me.DataGridView1.Columns(4).Width = 100
        Me.DataGridView1.Columns(0).Width = 50
        Me.DataGridView1.Columns(5).Width = 100
        Me.DataGridView1.Columns(6).Width = 100
        Me.DataGridView1.Columns(7).Width = 100
        Me.DataGridView1.Columns(8).Width = 100
    End Sub


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox1.Text = "" And TextBox2.Text = "" Then
            MsgBox("ISI DATA DENGAN LENGKAP !")
        Else
            Dim jk As String
            If RadioButton1.Checked Then
                jk = "L"
            Else
                jk = "P"
            End If
            Dim cmd, cmd2 As MySqlCommand
            Dim Sqltambahan As String = "INSERT INTO penyiar(id_penyiar,nama_penyiar,ttl,jk,agama,alamat,no_hp,email,username)values ('" & TextBox5.Text & "','" & TextBox1.Text & "','" & TextBox2.Text & "','" & jk & "','" & ComboBox1.Text & "','" & TextBox7.Text & "','" & TextBox6.Text & "','" & TextBox9.Text & "','" & TextBox8.Text & "')"
            cmd = New MySqlCommand(Sqltambahan, konek)
            cmd.ExecuteNonQuery()
            Dim Sql As String = "INSERT INTO login(username,password)values ('" & TextBox8.Text & "','" & TextBox6.Text & "')"
            cmd2 = New MySqlCommand(Sql, konek)
            cmd2.ExecuteNonQuery()
            MsgBox("DATA BERHASIL DITAMBAHKAN")
            opentable()
            apus()
        End If
    End Sub

    Private Sub editpenyiar_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        opentable()
        konek()
        atur()
        apus()
    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        TextBox5.Text = DataGridView1.Rows(e.RowIndex).Cells(0).Value
        TextBox1.Text = DataGridView1.Rows(e.RowIndex).Cells(1).Value
        TextBox2.Text = DataGridView1.Rows(e.RowIndex).Cells(2).Value
        If DataGridView1.Rows(e.RowIndex).Cells(3).Value = "L" Then
            RadioButton1.Checked = True
        Else
            RadioButton2.Checked = True
        End If
        ComboBox1.Text = DataGridView1.Rows(e.RowIndex).Cells(4).Value
        TextBox7.Text = DataGridView1.Rows(e.RowIndex).Cells(5).Value
        TextBox6.Text = DataGridView1.Rows(e.RowIndex).Cells(6).Value
        TextBox9.Text = DataGridView1.Rows(e.RowIndex).Cells(7).Value
        TextBox8.Text = DataGridView1.Rows(e.RowIndex).Cells(8).Value
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        If TextBox1.Text = "" Or TextBox5.Text = "" Then
            MsgBox("DATA BELUM LENGKAP")
        Else
            Dim jk As String
            If RadioButton1.Checked Then
                jk = "L"
            Else
                jk = "P"
            End If
            Dim cmd5 As MySqlCommand
            cmd5 = New MySqlCommand(" UPDATE penyiar SET nama_penyiar ='" & TextBox1.Text & "', ttl = '" & TextBox2.Text & "', jk = '" & jk & "', agama = '" & ComboBox1.Text & "', alamat ='" & TextBox7.Text & "', no_hp = '" & TextBox6.Text & "', email = '" & TextBox9.Text & "', username = '" & TextBox8.Text & "' WHERE id_penyiar = '" & TextBox5.Text & "'", konek)
            cmd5.ExecuteNonQuery()
            MsgBox("Data Berhasil Disimpan")
            opentable()
            apus()
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim cmd2 As MySqlCommand
        cmd2 = New MySqlCommand("DELETE FROM penyiar where id_penyiar = '" & TextBox5.Text & "' ", konek)
        cmd2.ExecuteNonQuery()
        MsgBox("Yakin ingin hapus data?")
        MsgBox("DATA BERHASIL TERHAPUS")
        opentable()
        apus()
    End Sub

    Private Sub SIARANToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SIARANToolStripMenuItem.Click
        Me.Show()
        editJS.Show()
    End Sub

    Private Sub LEMBURToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LEMBURToolStripMenuItem.Click
        Me.Close()
        editJL.show()
    End Sub

    Private Sub PENYIARToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PENYIARToolStripMenuItem1.Click
        Me.Show()
    End Sub

    Private Sub KARYAWANToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KARYAWANToolStripMenuItem.Click
        Me.Close()
        editstaff.show()
    End Sub

    Private Sub PENYIARToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PENYIARToolStripMenuItem.Click
        Me.Close()
        absenpenyiar.Show()
    End Sub

    Private Sub STAFToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles STAFToolStripMenuItem.Click
        Me.Close()
        absenstaff.Show()
    End Sub

 
    Private Sub GAJIToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GAJIToolStripMenuItem.Click
        Me.Close()
        rekapgaji.Show()
    End Sub

    Private Sub GAJISTAFFToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GAJISTAFFToolStripMenuItem.Click
        Me.Close()
        gajistaff.Show()
    End Sub

    Private Sub PictureBox3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox3.Click
        Me.Hide()
        menuAdmin.Show()
    End Sub
End Class