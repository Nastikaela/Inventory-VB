﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.DATAKARYAWANToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.STAFToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.JADWALToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SIARANToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LEMBURToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EDITAKUNToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PENGGAJIANToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.PENYIARToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GAJIPEYIARToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GAJIKARYAWANToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.Button1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button1.Location = New System.Drawing.Point(1013, 499)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 27
        Me.Button1.Text = "SAVE"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'TextBox1
        '
        Me.TextBox1.Enabled = False
        Me.TextBox1.Location = New System.Drawing.Point(822, 399)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(266, 20)
        Me.TextBox1.TabIndex = 23
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(716, 466)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(99, 13)
        Me.Label5.TabIndex = 22
        Me.Label5.Text = "Jabatan                 :"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(717, 433)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(98, 13)
        Me.Label4.TabIndex = 21
        Me.Label4.Text = "Waktu Datang      :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(716, 402)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(100, 13)
        Me.Label3.TabIndex = 20
        Me.Label3.Text = "Nama Karyawan    :"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DATAKARYAWANToolStripMenuItem, Me.JADWALToolStripMenuItem, Me.EDITAKUNToolStripMenuItem, Me.PENGGAJIANToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1362, 24)
        Me.MenuStrip1.TabIndex = 17
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'DATAKARYAWANToolStripMenuItem
        '
        Me.DATAKARYAWANToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PENYIARToolStripMenuItem, Me.STAFToolStripMenuItem})
        Me.DATAKARYAWANToolStripMenuItem.Name = "DATAKARYAWANToolStripMenuItem"
        Me.DATAKARYAWANToolStripMenuItem.Size = New System.Drawing.Size(64, 20)
        Me.DATAKARYAWANToolStripMenuItem.Text = "ABSENSI"
        '
        'STAFToolStripMenuItem
        '
        Me.STAFToolStripMenuItem.Name = "STAFToolStripMenuItem"
        Me.STAFToolStripMenuItem.Size = New System.Drawing.Size(121, 22)
        Me.STAFToolStripMenuItem.Text = "STAF"
        '
        'JADWALToolStripMenuItem
        '
        Me.JADWALToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SIARANToolStripMenuItem, Me.LEMBURToolStripMenuItem})
        Me.JADWALToolStripMenuItem.Name = "JADWALToolStripMenuItem"
        Me.JADWALToolStripMenuItem.Size = New System.Drawing.Size(64, 20)
        Me.JADWALToolStripMenuItem.Text = "JADWAL"
        '
        'SIARANToolStripMenuItem
        '
        Me.SIARANToolStripMenuItem.Name = "SIARANToolStripMenuItem"
        Me.SIARANToolStripMenuItem.Size = New System.Drawing.Size(119, 22)
        Me.SIARANToolStripMenuItem.Text = "SIARAN"
        '
        'LEMBURToolStripMenuItem
        '
        Me.LEMBURToolStripMenuItem.Name = "LEMBURToolStripMenuItem"
        Me.LEMBURToolStripMenuItem.Size = New System.Drawing.Size(119, 22)
        Me.LEMBURToolStripMenuItem.Text = "LEMBUR"
        '
        'EDITAKUNToolStripMenuItem
        '
        Me.EDITAKUNToolStripMenuItem.Name = "EDITAKUNToolStripMenuItem"
        Me.EDITAKUNToolStripMenuItem.Size = New System.Drawing.Size(78, 20)
        Me.EDITAKUNToolStripMenuItem.Text = "EDIT AKUN"
        '
        'PENGGAJIANToolStripMenuItem
        '
        Me.PENGGAJIANToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.GAJIPEYIARToolStripMenuItem, Me.GAJIKARYAWANToolStripMenuItem})
        Me.PENGGAJIANToolStripMenuItem.Name = "PENGGAJIANToolStripMenuItem"
        Me.PENGGAJIANToolStripMenuItem.Size = New System.Drawing.Size(80, 20)
        Me.PENGGAJIANToolStripMenuItem.Text = "REKAP GAJI"
        '
        'TextBox2
        '
        Me.TextBox2.Enabled = False
        Me.TextBox2.Location = New System.Drawing.Point(822, 464)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(266, 20)
        Me.TextBox2.TabIndex = 35
        '
        'TextBox3
        '
        Me.TextBox3.Enabled = False
        Me.TextBox3.Location = New System.Drawing.Point(986, 430)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(102, 20)
        Me.TextBox3.TabIndex = 36
        '
        'TextBox4
        '
        Me.TextBox4.Enabled = False
        Me.TextBox4.Location = New System.Drawing.Point(31, 245)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(74, 20)
        Me.TextBox4.TabIndex = 39
        Me.TextBox4.Visible = False
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(1053, 299)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(103, 55)
        Me.DataGridView1.TabIndex = 38
        Me.DataGridView1.Visible = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Garamond", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.SteelBlue
        Me.Label1.Location = New System.Drawing.Point(673, 152)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(229, 17)
        Me.Label1.TabIndex = 88
        Me.Label1.Text = "Telp. (021) 8619412,8619407,8619413"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Garamond", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.SteelBlue
        Me.Label2.Location = New System.Drawing.Point(566, 133)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(457, 17)
        Me.Label2.TabIndex = 87
        Me.Label2.Text = "Jl. Swadaya Raya 26 No. 143 Radin Inten  Duren Sawit – Jakarta Timur"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Stencil Std", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Firebrick
        Me.Label7.Location = New System.Drawing.Point(475, 70)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(636, 63)
        Me.Label7.TabIndex = 86
        Me.Label7.Text = "RADIO SABANA SAMHAN"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.WindowsApplication1.My.Resources.Resources.radio1
        Me.PictureBox1.Location = New System.Drawing.Point(198, 70)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(271, 140)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 85
        Me.PictureBox1.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = Global.WindowsApplication1.My.Resources.Resources.home
        Me.PictureBox3.Location = New System.Drawing.Point(1274, 16)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(56, 53)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 57
        Me.PictureBox3.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox2.Image = Global.WindowsApplication1.My.Resources.Resources.mmo
        Me.PictureBox2.Location = New System.Drawing.Point(213, 299)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(497, 323)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 33
        Me.PictureBox2.TabStop = False
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DateTimePicker1.Location = New System.Drawing.Point(822, 430)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(153, 20)
        Me.DateTimePicker1.TabIndex = 89
        '
        'PENYIARToolStripMenuItem
        '
        Me.PENYIARToolStripMenuItem.Name = "PENYIARToolStripMenuItem"
        Me.PENYIARToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.PENYIARToolStripMenuItem.Text = "PENYIAR"
        '
        'GAJIPEYIARToolStripMenuItem
        '
        Me.GAJIPEYIARToolStripMenuItem.Name = "GAJIPEYIARToolStripMenuItem"
        Me.GAJIPEYIARToolStripMenuItem.Size = New System.Drawing.Size(165, 22)
        Me.GAJIPEYIARToolStripMenuItem.Text = "GAJI PEYIAR"
        '
        'GAJIKARYAWANToolStripMenuItem
        '
        Me.GAJIKARYAWANToolStripMenuItem.Name = "GAJIKARYAWANToolStripMenuItem"
        Me.GAJIKARYAWANToolStripMenuItem.Size = New System.Drawing.Size(165, 22)
        Me.GAJIKARYAWANToolStripMenuItem.Text = "GAJI KARYAWAN"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1362, 741)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents DATAKARYAWANToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents STAFToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents JADWALToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SIARANToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LEMBURToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PENGGAJIANToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents EDITAKUNToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents PENYIARToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GAJIPEYIARToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GAJIKARYAWANToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
