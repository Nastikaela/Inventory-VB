﻿Imports MySql.Data.MySqlClient
Imports System.Data.SqlClient
Imports System.Data

Public Class login
    Dim koneksi As MySqlConnection
    Dim sql, username, password As String
    Dim cmd, cmd2 As MySqlCommand
    Dim rd, rd2 As MySqlDataReader

    Sub clear()
        TextBox1.Text = ""
        TextBox2.Text = ""
    End Sub
   
    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim strKoneksi As String
        strKoneksi = "server='localhost';user id='root';password='';database='radio'"
        koneksi = New MySqlConnection(strKoneksi)
        Try
            koneksi.Open()
        Catch ex As Exception
        End Try
    End Sub

    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        username = TextBox1.Text
        password = TextBox2.Text
        If TextBox1.Text = "" Then
            MsgBox("Isi data dahulu!!!!")
            TextBox1.Focus()

        ElseIf TextBox1.Text = "admin" Then
            sql = "Select * from login where username='" + username + "' and password='" + password + "'"
            cmd = New MySqlCommand(sql, konek)
            rd = cmd.ExecuteReader
            rd.Read()
            If rd.HasRows Then
                MsgBox("ANDA BERHASIL LOGIN")
                TextBox1.Text = ""
                TextBox2.Text = ""
                menuAdmin.Show()
                Me.Hide()
                rd.Close()
            Else
                MsgBox("MAAF DATA YANG ANDA MASUKAN SALAH.")
                TextBox1.Text = ""
                TextBox2.Text = ""
                TextBox1.Focus()
            End If
        ElseIf TextBox1.Text = "keuangan" Then
            sql = "Select * from login where username='" + username + "' and password='" + password + "'"
            cmd = New MySqlCommand(sql, konek)
            rd = cmd.ExecuteReader
            rd.Read()
            If rd.HasRows Then
                MsgBox("ANDA BERHASIL LOGIN")
                TextBox1.Text = ""
                TextBox2.Text = ""
                menuKeuangan.Show()
                Me.Hide()
                rd.Close()
            Else
                MsgBox("MAAF DATA YANG ANDA MASUKAN SALAH.")
                TextBox1.Text = ""
                TextBox2.Text = ""
                TextBox1.Focus()
            End If
        Else
            sql = "Select * from login where username='" + username + "' and password='" + password + "'"
            cmd2 = New MySqlCommand(sql, konek)
            rd2 = cmd2.ExecuteReader
            rd2.Read()
            If rd2.HasRows Then
                Dim cmd3 As MySqlCommand
                Dim Sqltambahan As String = "INSERT INTO riwayat(username)values ('" & TextBox1.Text & "')"
                cmd3 = New MySqlCommand(Sqltambahan, konek)
                cmd3.ExecuteNonQuery()
                MsgBox("ANDA BERHASIL LOGIN")
                clear()
                menuUser.Show()
                Me.Hide()
                rd2.Close()
            Else
                MsgBox("MAAF DATA YANG ANDA MASUKAN SALAH.")
                TextBox1.Text = ""
                TextBox2.Text = ""
                TextBox1.Focus()
            End If

        End If
    End Sub
End Class
