﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class menuKeuangan
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GAJISTAFFToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.EDITAKUNToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.KARYAWANToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PENGGAJIANToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GAJIPENYIARToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EDITAKUNToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Adobe Caslon Pro Bold", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.SteelBlue
        Me.Label8.Location = New System.Drawing.Point(576, 524)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(770, 29)
        Me.Label8.TabIndex = 95
        Me.Label8.Text = "Segera lakukan absensi ketika memasuki ruangan siaran untuk mencegah kekelirruan " & _
            "dalam pengabsenan"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Adobe Caslon Pro Bold", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.SteelBlue
        Me.Label7.Location = New System.Drawing.Point(670, 498)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(517, 29)
        Me.Label7.TabIndex = 94
        Me.Label7.Text = "dan juga rekap gaji selama menjadi karyawan di Radio Sabana Samhan"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Adobe Caslon Pro Bold", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.SteelBlue
        Me.Label5.Location = New System.Drawing.Point(670, 442)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(511, 29)
        Me.Label5.TabIndex = 92
        Me.Label5.Text = "Aplikasi ini dipergunakan oleh Karyawan PT. Radio Sabana Samhan."
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Garamond", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.SteelBlue
        Me.Label3.Location = New System.Drawing.Point(679, 186)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(229, 17)
        Me.Label3.TabIndex = 91
        Me.Label3.Text = "Telp. (021) 8619412,8619407,8619413"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Garamond", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.SteelBlue
        Me.Label1.Location = New System.Drawing.Point(572, 167)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(457, 17)
        Me.Label1.TabIndex = 90
        Me.Label1.Text = "Jl. Swadaya Raya 26 No. 143 Radin Inten  Duren Sawit – Jakarta Timur"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Stencil Std", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Firebrick
        Me.Label2.Location = New System.Drawing.Point(481, 104)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(636, 63)
        Me.Label2.TabIndex = 89
        Me.Label2.Text = "RADIO SABANA SAMHAN"
        '
        'GAJISTAFFToolStripMenuItem
        '
        Me.GAJISTAFFToolStripMenuItem.Name = "GAJISTAFFToolStripMenuItem"
        Me.GAJISTAFFToolStripMenuItem.Size = New System.Drawing.Size(165, 22)
        Me.GAJISTAFFToolStripMenuItem.Text = "GAJI KARYAWAN"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Adobe Caslon Pro Bold", 12.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.SteelBlue
        Me.Label4.Location = New System.Drawing.Point(589, 468)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(737, 29)
        Me.Label4.TabIndex = 93
        Me.Label4.Text = "Dengan adanya aplikasi ini memudahkan Karyawan dalam melakukan absensi, melihat j" & _
            "adwal siaran "
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EDITAKUNToolStripMenuItem, Me.EDITAKUNToolStripMenuItem1, Me.PENGGAJIANToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1362, 24)
        Me.MenuStrip1.TabIndex = 87
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'EDITAKUNToolStripMenuItem
        '
        Me.EDITAKUNToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.KARYAWANToolStripMenuItem})
        Me.EDITAKUNToolStripMenuItem.Name = "EDITAKUNToolStripMenuItem"
        Me.EDITAKUNToolStripMenuItem.Size = New System.Drawing.Size(118, 20)
        Me.EDITAKUNToolStripMenuItem.Text = "DATA KARYAWAN"
        '
        'KARYAWANToolStripMenuItem
        '
        Me.KARYAWANToolStripMenuItem.Name = "KARYAWANToolStripMenuItem"
        Me.KARYAWANToolStripMenuItem.Size = New System.Drawing.Size(146, 22)
        Me.KARYAWANToolStripMenuItem.Text = "EDIT STATUS "
        '
        'PENGGAJIANToolStripMenuItem
        '
        Me.PENGGAJIANToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.GAJIPENYIARToolStripMenuItem, Me.GAJISTAFFToolStripMenuItem})
        Me.PENGGAJIANToolStripMenuItem.Name = "PENGGAJIANToolStripMenuItem"
        Me.PENGGAJIANToolStripMenuItem.Size = New System.Drawing.Size(80, 20)
        Me.PENGGAJIANToolStripMenuItem.Text = "REKAP GAJI"
        '
        'GAJIPENYIARToolStripMenuItem
        '
        Me.GAJIPENYIARToolStripMenuItem.Name = "GAJIPENYIARToolStripMenuItem"
        Me.GAJIPENYIARToolStripMenuItem.Size = New System.Drawing.Size(165, 22)
        Me.GAJIPENYIARToolStripMenuItem.Text = "GAJI PENYIAR"
        '
        'EDITAKUNToolStripMenuItem1
        '
        Me.EDITAKUNToolStripMenuItem1.Name = "EDITAKUNToolStripMenuItem1"
        Me.EDITAKUNToolStripMenuItem1.Size = New System.Drawing.Size(78, 20)
        Me.EDITAKUNToolStripMenuItem1.Text = "EDIT AKUN"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.WindowsApplication1.My.Resources.Resources.Radistation_flat_vector_illustration_2
        Me.PictureBox1.Location = New System.Drawing.Point(15, 332)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(566, 374)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 96
        Me.PictureBox1.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.WindowsApplication1.My.Resources.Resources.radio1
        Me.PictureBox2.Location = New System.Drawing.Point(219, 88)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(271, 140)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 88
        Me.PictureBox2.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = Global.WindowsApplication1.My.Resources.Resources.gnome_panel_force_quit
        Me.PictureBox3.Location = New System.Drawing.Point(1268, 27)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(58, 56)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 97
        Me.PictureBox3.TabStop = False
        '
        'menuKeuangan
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1362, 741)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.PictureBox3)
        Me.Name = "menuKeuangan"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form2"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents GAJISTAFFToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents EDITAKUNToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents KARYAWANToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PENGGAJIANToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GAJIPENYIARToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents EDITAKUNToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
End Class
