﻿Imports MySql.Data.MySqlClient
Imports System.Data.SqlClient
Imports System.Data

Module Module1
    Dim myconn As New MySqlConnection
    Dim mycommand As New MySqlCommand
    Dim myadapter As New MySqlDataAdapter
    Dim mydata As New DataTable
    Dim reader As MySqlDataReader

    Public Function konek() As MySqlConnection
        myconn = New MySqlConnection("server='localhost';user id='root';password='';database='radio';convert Zero DateTime='True'")
        myconn.Open()
        Return myconn
    End Function


End Module

