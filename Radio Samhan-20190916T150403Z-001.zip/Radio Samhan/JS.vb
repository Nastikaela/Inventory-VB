﻿Imports MySql.Data.MySqlClient
Imports System.Data.SqlClient
Imports System.Data

Public Class JS
    Dim cmd As MySqlCommand

    Sub opentable()
        Dim myadapter As New MySqlDataAdapter("select * from jadwal", konek)
        Dim mydata As New DataTable
        myadapter.Fill(mydata)
        DataGridView1.DataSource = mydata
    End Sub

    Sub atur()
        Me.DataGridView1.Columns(0).HeaderText = "ID JADWAL"
        Me.DataGridView1.Columns(1).HeaderText = "HARI SIARAN"
        Me.DataGridView1.Columns(2).HeaderText = "WAKTU SIARAN"
        Me.DataGridView1.Columns(3).HeaderText = "NAMA ACARA"
        Me.DataGridView1.Columns(4).HeaderText = "NAMA PENYIAR"
        Me.DataGridView1.Columns(1).Width = 150
        Me.DataGridView1.Columns(2).Width = 150
        Me.DataGridView1.Columns(3).Width = 150
        Me.DataGridView1.Columns(0).Width = 150
        Me.DataGridView1.Columns(4).Width = 150


    End Sub
    Sub hak()
        Dim cmd, cmd2, cmd3, cmd4 As New MySqlCommand
        Dim rd, rd2, rd3, rd4 As MySqlDataReader
        cmd = New MySqlCommand("select * from riwayat order by id DESC", konek)
        rd = cmd.ExecuteReader
        If rd.Read Then
            TextBox1.Text = rd.Item("username")
            rd.Close()
        End If
        cmd4 = New MySqlCommand("select * from dua where username = '" & TextBox1.Text & "' ", konek)
        rd4 = cmd4.ExecuteReader
        cmd2 = New MySqlCommand("select * from penyiar where username = '" & TextBox1.Text & "' ", konek)
        rd2 = cmd2.ExecuteReader
        cmd3 = New MySqlCommand("select * from karyawan where username = '" & TextBox1.Text & "' ", konek)
        rd3 = cmd3.ExecuteReader

        If rd4.Read Then
            STAFToolStripMenuItem.Enabled = True
            PENYIARToolStripMenuItem.Enabled = True
        ElseIf rd2.Read Then
            STAFToolStripMenuItem.Enabled = False
            GAJIKARYAWANToolStripMenuItem.Enabled = False
        Else
            PENYIARToolStripMenuItem.Enabled = False
            GAJIPENYIARToolStripMenuItem.Enabled = False
        End If
        rd.Close()
    End Sub
    Private Sub Form3_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        opentable()
        atur()
        konek()
        hak()
    End Sub

    Private Sub PENYIARToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Close()
        AP.Show()
    End Sub

    Private Sub SIARANToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Show()
    End Sub

    Private Sub LEMBURToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Close()
        JL.Show()
    End Sub

    Private Sub PENGGAJIANToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Close()
        gajistaff.Show()
    End Sub

    Private Sub EDITAKUNToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Close()
        editakun.Show()
    End Sub

    Private Sub STAFToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Close()
        Form1.Show()
    End Sub

    Private Sub PictureBox3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Close()
        menuUser.Show()
    End Sub

    Private Sub LEMBURToolStripMenuItem_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LEMBURToolStripMenuItem.Click
        Me.Close()
        JL.Show()
    End Sub

    Private Sub PictureBox3_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox3.Click
        Me.Close()
        menuUser.Show()
    End Sub

    Private Sub EDITAKUNToolStripMenuItem_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EDITAKUNToolStripMenuItem.Click
        Me.Close()
        editakun.Show()
    End Sub
End Class