﻿Public Class menuAdmin

    Private Sub PENYIARToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PENYIARToolStripMenuItem.Click
        absenpenyiar.Show()
    End Sub

    Private Sub STAFToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles STAFToolStripMenuItem.Click
        absenstaff.Show()
    End Sub

    Private Sub SIARANToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SIARANToolStripMenuItem.Click
        editJS.Show()
    End Sub

    Private Sub LEMBURToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LEMBURToolStripMenuItem.Click
        editJL.Show()
    End Sub

    Private Sub KARYAWANToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KARYAWANToolStripMenuItem.Click
        editstaff.Show()
    End Sub

    Private Sub PENYIARToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PENYIARToolStripMenuItem1.Click
        editpenyiar.Show()
    End Sub

    Private Sub GAJIPENYIARToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GAJIPENYIARToolStripMenuItem.Click
        rekapgaji.Show()
    End Sub

    Private Sub GAJISTAFFToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GAJISTAFFToolStripMenuItem.Click
        gajistaff.Show()
    End Sub

    Private Sub PictureBox3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox3.Click
        MsgBox("Anda Yakin Ingin Keluar??")
        Me.Close()
        login.Show()
    End Sub
End Class