﻿Imports MySql.Data.MySqlClient
Imports System.Data.SqlClient
Imports System.Data

Public Class statusstaff

    Sub opentable()
        Dim myadapter As New MySqlDataAdapter("select id_karyawan,tgl_kerja,nama_karyawan,jabatan,status from karyawan", konek)
        Dim mydata As New DataTable
        myadapter.Fill(mydata)
        DataGridView1.DataSource = mydata
    End Sub
    Sub apus()
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
    End Sub
    Sub atur()
        Me.DataGridView1.Columns(0).HeaderText = "ID"
        Me.DataGridView1.Columns(1).HeaderText = "TANGGAL BEKERJA"
        Me.DataGridView1.Columns(2).HeaderText = "NAMA LENGKAP"
        Me.DataGridView1.Columns(3).HeaderText = "JABATAN"
        Me.DataGridView1.Columns(4).HeaderText = "STATUS STAFF"
        Me.DataGridView1.Columns(0).Width = 150
        Me.DataGridView1.Columns(2).Width = 150
        Me.DataGridView1.Columns(3).Width = 150
        Me.DataGridView1.Columns(4).Width = 150
        Me.DataGridView1.Columns(1).Width = 150
    End Sub
    Private Sub statusstaff_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        opentable()
        atur()
        konek()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox2.Text = "" Then
            MsgBox("DATA BELUM LENGKAP")
        Else
            Dim cmd As MySqlCommand
            cmd = New MySqlCommand(" UPDATE karyawan SET status= '" & TextBox2.Text & "' where nama_karyawan = '" & TextBox5.Text & "'", konek)
            cmd.ExecuteNonQuery()
            MsgBox("Data Berhasil Disimpan")
            opentable()
            apus()
        End If
    End Sub

    Private Sub KARYAWANToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KARYAWANToolStripMenuItem.Click
        Me.Show()
    End Sub

    Private Sub DataGridView1_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles DataGridView1.CellMouseClick
        TextBox1.Text = DataGridView1.Rows(e.RowIndex).Cells(1).Value
        TextBox5.Text = DataGridView1.Rows(e.RowIndex).Cells(2).Value
        TextBox3.Text = DataGridView1.Rows(e.RowIndex).Cells(3).Value
        TextBox2.Text = DataGridView1.Rows(e.RowIndex).Cells(4).Value
        TextBox4.Text = DataGridView1.Rows(e.RowIndex).Cells(0).Value
    End Sub

   
    Private Sub GAJISTAFFToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GAJISTAFFToolStripMenuItem.Click
        Me.Hide()
        gajistaff.Show()
    End Sub

    Private Sub GAJIPENYIARToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GAJIPENYIARToolStripMenuItem.Click
        Me.Close()
        rekapgaji.Show()
    End Sub
End Class