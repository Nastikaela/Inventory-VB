﻿Imports MySql.Data.MySqlClient
Imports System.Data.SqlClient
Imports System.Data

Public Class absenpenyiar

    Sub opentable()
        Dim myadapter As New MySqlDataAdapter("select * from absen_penyiar", konek)
        Dim mydata As New DataTable
        myadapter.Fill(mydata)
        DataGridView1.DataSource = mydata
    End Sub

    Sub atur()
        Me.DataGridView1.Columns(0).HeaderText = "HARI SIARAN"
        Me.DataGridView1.Columns(1).HeaderText = "WAKTU ABSEN"
        Me.DataGridView1.Columns(2).HeaderText = "NAMA ACARA"
        Me.DataGridView1.Columns(3).HeaderText = "NAMA PENYIAR"
        Me.DataGridView1.Columns(4).HeaderText = "DURASI SIARAN"
        Me.DataGridView1.Columns(0).Width = 150
        Me.DataGridView1.Columns(2).Width = 180
        Me.DataGridView1.Columns(3).Width = 160
        Me.DataGridView1.Columns(1).Width = 150
        Me.DataGridView1.Columns(4).Width = 150

    End Sub

    Private Sub absenstaff_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim cmd, cmd2 As New MySqlCommand
        Dim rdr As MySqlDataReader

        cmd = New MySqlCommand("select distinct nama_penyiar FROM absen_penyiar ", konek)
        rdr = cmd.ExecuteReader
        While rdr.Read
            ComboBox2.Items.Add(rdr.Item(0))
        End While
        opentable()
        konek()
        atur()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

   
    Private Sub STAFToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles STAFToolStripMenuItem.Click
        Me.Close()
        absenstaff.Show()
    End Sub

    Private Sub SIARANToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SIARANToolStripMenuItem.Click
        Me.Close()
        editJS.Show()
    End Sub

    Private Sub LEMBURToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LEMBURToolStripMenuItem.Click
        Me.Close()
        editJL.Show()
    End Sub

    Private Sub PENYIARToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PENYIARToolStripMenuItem1.Click
        Me.Close()
        editpenyiar.Show()
    End Sub

    Private Sub KARYAWANToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KARYAWANToolStripMenuItem.Click
        Me.Close()
        editstaff.Show()
    End Sub

    'Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
    '    ComboBox2 = DataGridView1.Rows(e.RowIndex).Cells(3).Value
    'End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim bulan As String
        bulan = ComboBox1.Text
        Select Case bulan
            Case "Januari"
                TextBox1.Text = "01"
            Case "Februari"
                TextBox1.Text = "02"
            Case "Maret"
                TextBox1.Text = "03"
            Case "April"
                TextBox1.Text = "04"
            Case "Mei"
                TextBox1.Text = "05"
            Case "Juni"
                TextBox1.Text = "06"
            Case "Juli"
                TextBox1.Text = "07"
            Case "Agustus"
                TextBox1.Text = "08"
            Case "September"
                TextBox1.Text = "09"
            Case "Oktober"
                TextBox1.Text = "10"
            Case "November"
                TextBox1.Text = "11"
            Case "Desember"
                TextBox1.Text = "12"
        End Select
        Dim myadapter As New MySqlDataAdapter("select * from absen_penyiar where nama_penyiar = '" & ComboBox2.Text & "' and tanggal LIKE '%-" & TextBox1.Text & "-%' ", konek)
        Dim mydata As New DataTable
        myadapter.Fill(mydata)
        DataGridView1.DataSource = mydata

    End Sub

    Private Sub GAJIPENYIARToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GAJIPENYIARToolStripMenuItem.Click
        Me.Close()
        rekapgaji.Show()
    End Sub

    Private Sub GAJISTAFFToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GAJISTAFFToolStripMenuItem.Click
        Me.Close()
        gajistaff.Show()
    End Sub
End Class