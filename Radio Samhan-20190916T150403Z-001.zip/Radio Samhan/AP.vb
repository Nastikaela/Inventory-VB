﻿Imports MySql.Data.MySqlClient
Imports System.Data.SqlClient
Imports System.Data

Public Class AP
    Dim koneksi As MySqlConnection
    Dim sql, username, password As String
    Dim cmd, cmd2, cmd3, cm4 As MySqlCommand
    Dim rd, rd2, rd3, rd4 As MySqlDataReader

    Sub opentable()
        Dim myadapter As New MySqlDataAdapter("select * from riwayat", konek)
        Dim mydata As New DataTable
        myadapter.Fill(mydata)
        DataGridView1.DataSource = mydata
    End Sub
    Sub hak()
        Dim cmd, cmd2, cmd3, cmd4 As New MySqlCommand
        Dim rd, rd2, rd3, rd4 As MySqlDataReader
        cmd = New MySqlCommand("select * from riwayat order by id DESC", konek)
        rd = cmd.ExecuteReader
        If rd.Read Then
            TextBox1.Text = rd.Item("username")
            rd.Close()
        End If
        cmd4 = New MySqlCommand("select * from dua where username = '" & TextBox1.Text & "' ", konek)
        rd4 = cmd4.ExecuteReader
        cmd2 = New MySqlCommand("select * from penyiar where username = '" & TextBox1.Text & "' ", konek)
        rd2 = cmd2.ExecuteReader
        cmd3 = New MySqlCommand("select * from karyawan where username = '" & TextBox1.Text & "' ", konek)
        rd3 = cmd3.ExecuteReader

        If rd4.Read Then
            STAFToolStripMenuItem.Enabled = True
            PENYIARToolStripMenuItem.Enabled = True
        ElseIf rd2.Read Then
            STAFToolStripMenuItem.Enabled = False
            GAJIKARYAWANToolStripMenuItem.Enabled = False
        Else
            PENYIARToolStripMenuItem.Enabled = False
            GAJIPENYIARToolStripMenuItem.Enabled = False
        End If
        rd.Close()
    End Sub
    Sub nama()
        cmd = New MySqlCommand("select * from riwayat order by id DESC", konek)
        rd = cmd.ExecuteReader
        If rd.Read Then
            TextBox4.Text = rd.Item("username")
            rd.Close()
        End If
        cmd2 = New MySqlCommand("select * from penyiar where username = '" & TextBox4.Text & "' ", konek)
        rd2 = cmd2.ExecuteReader
        If rd2.Read Then
            TextBox1.Text = rd2.Item("nama_penyiar")
            rd2.Close()
        End If
        cmd = New MySqlCommand("select distinct nama_acara FROM jadwal where penyiar = '" & TextBox1.Text & "' ", konek)
        rd = cmd.ExecuteReader
        While rd.Read
            ComboBox1.Items.Add(rd.Item(0))
        End While
        rd.Close()
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        cmd = New MySqlCommand("select durasi FROM jadwal where penyiar = '" & TextBox1.Text & "' and nama_acara = '" & ComboBox1.Text & "'", konek)
        rd = cmd.ExecuteReader
        While rd.Read
            TextBox2.Text = rd.Item("durasi")
        End While
    End Sub

    Private Sub AP_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        opentable()
        konek()
        hak()
        nama()
        DateTimePicker1.Format = DateTimePickerFormat.Custom
        DateTimePicker1.CustomFormat = "d/MMMM/yyyy"
        TextBox3.Text = Format(Now, "HH:mm:ss")
    End Sub


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If ComboBox1.Text = "" Then
            MsgBox("PILIH ACARA SIARAN TERLEBIH DAHULU !")
        Else
            Dim Sqltambahan As String = "INSERT INTO absen_penyiar(nama_penyiar,tanggal,waktu,nama_acara,durasi)values ('" & TextBox1.Text & "','" & Format(DateTimePicker1.Value, "yyyy-MM-dd") & "','" & TextBox3.Text & "','" & ComboBox1.Text & "', '" & TextBox2.Text & "')"
            cmd = New MySqlCommand(Sqltambahan, konek)
            cmd.ExecuteNonQuery()
            MsgBox("ABSEN BERHASIL DI SIMPAN")
            Me.Close()
            menuUser.Show()
        End If
    End Sub

    Private Sub PENYIARToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PENYIARToolStripMenuItem.Click
        Me.Show()
    End Sub

    Private Sub SIARANToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SIARANToolStripMenuItem.Click
        Me.Close()
        JS.Show()
    End Sub

    Private Sub LEMBURToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LEMBURToolStripMenuItem.Click
        Me.Close()
        JL.Show()
    End Sub

    Private Sub PENGGAJIANToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PENGGAJIANToolStripMenuItem.Click
        Me.Close()
        gajistaff.Show()
    End Sub

    Private Sub EDITAKUNToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Close()
        editakun.Show()
    End Sub

    Private Sub STAFToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles STAFToolStripMenuItem.Click
        Me.Close()
        Form1.Show()
    End Sub

    Private Sub PictureBox3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Close()
        menuUser.Show()
    End Sub

    Private Sub PictureBox3_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox3.Click
        Me.Close()
        menuUser.Show()
    End Sub

    
    Private Sub EDITAKUNToolStripMenuItem_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EDITAKUNToolStripMenuItem.Click
        Me.Close()
        editakun.Show()
    End Sub

End Class