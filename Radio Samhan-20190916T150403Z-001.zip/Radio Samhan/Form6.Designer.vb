﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class form6
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.EDITAKUNToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.KARYAWANToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EDITAKUNToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PENGGAJIANToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GAJIPENYIARToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GAJISTAFFToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EDITAKUNToolStripMenuItem, Me.EDITAKUNToolStripMenuItem1, Me.PENGGAJIANToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1362, 24)
        Me.MenuStrip1.TabIndex = 248
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'EDITAKUNToolStripMenuItem
        '
        Me.EDITAKUNToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.KARYAWANToolStripMenuItem})
        Me.EDITAKUNToolStripMenuItem.Name = "EDITAKUNToolStripMenuItem"
        Me.EDITAKUNToolStripMenuItem.Size = New System.Drawing.Size(118, 20)
        Me.EDITAKUNToolStripMenuItem.Text = "DATA KARYAWAN"
        '
        'KARYAWANToolStripMenuItem
        '
        Me.KARYAWANToolStripMenuItem.Name = "KARYAWANToolStripMenuItem"
        Me.KARYAWANToolStripMenuItem.Size = New System.Drawing.Size(146, 22)
        Me.KARYAWANToolStripMenuItem.Text = "EDIT STATUS "
        '
        'EDITAKUNToolStripMenuItem1
        '
        Me.EDITAKUNToolStripMenuItem1.Name = "EDITAKUNToolStripMenuItem1"
        Me.EDITAKUNToolStripMenuItem1.Size = New System.Drawing.Size(78, 20)
        Me.EDITAKUNToolStripMenuItem1.Text = "EDIT AKUN"
        '
        'PENGGAJIANToolStripMenuItem
        '
        Me.PENGGAJIANToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.GAJIPENYIARToolStripMenuItem, Me.GAJISTAFFToolStripMenuItem})
        Me.PENGGAJIANToolStripMenuItem.Name = "PENGGAJIANToolStripMenuItem"
        Me.PENGGAJIANToolStripMenuItem.Size = New System.Drawing.Size(80, 20)
        Me.PENGGAJIANToolStripMenuItem.Text = "REKAP GAJI"
        '
        'GAJIPENYIARToolStripMenuItem
        '
        Me.GAJIPENYIARToolStripMenuItem.Name = "GAJIPENYIARToolStripMenuItem"
        Me.GAJIPENYIARToolStripMenuItem.Size = New System.Drawing.Size(165, 22)
        Me.GAJIPENYIARToolStripMenuItem.Text = "GAJI PENYIAR"
        '
        'GAJISTAFFToolStripMenuItem
        '
        Me.GAJISTAFFToolStripMenuItem.Name = "GAJISTAFFToolStripMenuItem"
        Me.GAJISTAFFToolStripMenuItem.Size = New System.Drawing.Size(165, 22)
        Me.GAJISTAFFToolStripMenuItem.Text = "GAJI KARYAWAN"
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = Global.WindowsApplication1.My.Resources.Resources.home
        Me.PictureBox3.Location = New System.Drawing.Point(1271, 27)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(56, 53)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 247
        Me.PictureBox3.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Garamond", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.SteelBlue
        Me.Label1.Location = New System.Drawing.Point(725, 179)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(229, 17)
        Me.Label1.TabIndex = 246
        Me.Label1.Text = "Telp. (021) 8619412,8619407,8619413"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Garamond", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.SteelBlue
        Me.Label2.Location = New System.Drawing.Point(618, 160)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(457, 17)
        Me.Label2.TabIndex = 245
        Me.Label2.Text = "Jl. Swadaya Raya 26 No. 143 Radin Inten  Duren Sawit – Jakarta Timur"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Stencil Std", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Firebrick
        Me.Label6.Location = New System.Drawing.Point(527, 97)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(636, 63)
        Me.Label6.TabIndex = 244
        Me.Label6.Text = "RADIO SABANA SAMHAN"
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.WindowsApplication1.My.Resources.Resources.radio1
        Me.PictureBox2.Location = New System.Drawing.Point(264, 75)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(271, 140)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 249
        Me.PictureBox2.TabStop = False
        '
        'TextBox4
        '
        Me.TextBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox4.Location = New System.Drawing.Point(881, 300)
        Me.TextBox4.Multiline = True
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(240, 35)
        Me.TextBox4.TabIndex = 258
        Me.TextBox4.Visible = False
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(1029, 517)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(92, 37)
        Me.Button1.TabIndex = 257
        Me.Button1.Text = "SIMPAN"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.WindowsApplication1.My.Resources.Resources.professional_programmer_engineer_writing_code_3446_693
        Me.PictureBox1.Location = New System.Drawing.Point(240, 240)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(396, 377)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 256
        Me.PictureBox1.TabStop = False
        '
        'TextBox3
        '
        Me.TextBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox3.Location = New System.Drawing.Point(881, 456)
        Me.TextBox3.Multiline = True
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(240, 35)
        Me.TextBox3.TabIndex = 255
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(683, 461)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(179, 24)
        Me.Label7.TabIndex = 254
        Me.Label7.Text = "Password Baru    :"
        '
        'TextBox2
        '
        Me.TextBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.Location = New System.Drawing.Point(881, 417)
        Me.TextBox2.Multiline = True
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(240, 32)
        Me.TextBox2.TabIndex = 253
        '
        'TextBox1
        '
        Me.TextBox1.Enabled = False
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(881, 375)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(240, 35)
        Me.TextBox1.TabIndex = 252
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(682, 418)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(180, 24)
        Me.Label5.TabIndex = 251
        Me.Label5.Text = "Password Lama   :"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(680, 377)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(183, 24)
        Me.Label4.TabIndex = 250
        Me.Label4.Text = "Username            :"
        '
        'Form6
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1362, 741)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label6)
        Me.Name = "Form6"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form6"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents EDITAKUNToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents KARYAWANToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EDITAKUNToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PENGGAJIANToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GAJIPENYIARToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GAJISTAFFToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
End Class
