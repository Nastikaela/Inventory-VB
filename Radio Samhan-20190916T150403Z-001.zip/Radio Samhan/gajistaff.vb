﻿Imports MySql.Data.MySqlClient
Imports System.Data.SqlClient
Imports System.Data

Public Class gajistaff

    Dim koneksi As MySqlConnection
    Dim sql, username, password As String
    Dim cmd, cmd2 As MySqlCommand
    Dim rd, rd2 As MySqlDataReader


    Sub atur()
        Me.DataGridView1.Columns(0).HeaderText = "BULAN"
        Me.DataGridView1.Columns(1).HeaderText = "NAMA KARYAWAN"
        Me.DataGridView1.Columns(2).HeaderText = "TOTAL GAJI"
        Me.DataGridView1.Columns(0).Width = 250
        Me.DataGridView1.Columns(2).Width = 300
        Me.DataGridView1.Columns(1).Width = 300

    End Sub

    Sub tableabsen()
        Dim myadapter As New MySqlDataAdapter("select * from absen_karyawan", konek)
        Dim mydata As New DataTable
        myadapter.Fill(mydata)
        DataGridView2.DataSource = mydata
    End Sub

    Sub status()
        Dim myadapter As New MySqlDataAdapter("select nama_karyawan, status from karyawan where nama_karyawan = '" & ComboBox2.Text & "' ", konek)
        Dim mydata As New DataTable
        myadapter.Fill(mydata)
        DataGridView3.DataSource = mydata
        cmd = New MySqlCommand("select status FROM karyawan where nama_karyawan = '" & ComboBox2.Text & "'", konek)
        rd = cmd.ExecuteReader
        While rd.Read
            TextBox5.Text = rd.Item("status")
        End While
    End Sub

    Sub gaji()
        Dim myadapter3 As New MySqlDataAdapter("select bulan,namastaff,gaji from gajistaff where namastaff = '" & ComboBox2.Text & "' and bulan= '" & ComboBox1.Text & "' ORDER BY namastaff DESC LIMIT 1 ", konek)
        Dim mydata3 As New DataTable
        myadapter3.Fill(mydata3)
        DataGridView1.DataSource = mydata3
    End Sub

    Private Sub gajistaff_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim cmd As New MySqlCommand
        Dim cmd1, cmd2 As New MySqlCommand
        Dim rdr As MySqlDataReader

        cmd1 = New MySqlCommand("select distinct nama_karyawan FROM karyawan ", konek)
        rdr = cmd1.ExecuteReader
        While rdr.Read
            ComboBox2.Items.Add(rdr.Item(0))
        End While
        tableabsen()
        konek()
    End Sub


    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim bulan As String
        bulan = ComboBox1.Text
        Select Case bulan
            Case "Januari"
                TextBox1.Text = "01"
                TextBox6.Text = "Januari"
            Case "Februari"
                TextBox1.Text = "02"
                TextBox6.Text = "Februari"
            Case "Maret"
                TextBox1.Text = "03"
                TextBox6.Text = "Maret"
            Case "April"
                TextBox1.Text = "04"
                TextBox6.Text = "April"
            Case "Mei"
                TextBox1.Text = "05"
                TextBox6.Text = "Mei"
            Case "Juni"
                TextBox1.Text = "06"
                TextBox6.Text = "Juni"
            Case "Juli"
                TextBox1.Text = "07"
                TextBox6.Text = "Juli"
            Case "Agustus"
                TextBox1.Text = "08"
                TextBox6.Text = "Agustus"
            Case "September"
                TextBox1.Text = "09"
                TextBox6.Text = "September"
            Case "Oktober"
                TextBox1.Text = "10"
                TextBox6.Text = "Oktober"
            Case "November"
                TextBox1.Text = "11"
                TextBox6.Text = "November"
            Case "Desember"
                TextBox1.Text = "12"
                TextBox6.Text = "Desember"
        End Select
        If ComboBox2.Text = "Semua" Then
            Dim myadapter1 As New MySqlDataAdapter("select distinct bulan,namastaff,gaji from gajistaff where bulan= '" & TextBox6.Text & "' ", konek)
            Dim mydata1 As New DataTable
            myadapter1.Fill(mydata1)
            DataGridView1.DataSource = mydata1
        Else
            Dim myadapter As New MySqlDataAdapter("select * from absen_karyawan where nama_karyawan = '" & ComboBox2.Text & "' and tanggal LIKE '%-" & TextBox1.Text & "-%' ", konek)
            Dim mydata As New DataTable
            myadapter.Fill(mydata)
            DataGridView2.DataSource = mydata

            Dim hitung As Integer
            For baris As Integer = 0 To DataGridView2.RowCount - 1
                hitung = hitung + DataGridView2.Rows(baris).Cells(4).Value
            Next
            TextBox3.Text = DataGridView2.RowCount - 1
            status()

            Dim transport, gp As Integer
            Dim st As String
            st = "Senior"
            If TextBox5.Text = st Then
                gp = Val(TextBox3.Text) * 100000
            Else
                gp = Val(TextBox3.Text) * 85000
            End If

            transport = Val(TextBox3.Text) * 30000
            TextBox4.Text = gp + transport

            Dim Sqltambah As String = "INSERT INTO gajistaff(bulan,namastaff,gaji)values ('" & TextBox6.Text & "','" & ComboBox2.Text & "','" & TextBox4.Text & "')"
            cmd = New MySqlCommand(Sqltambah, konek)
            cmd.ExecuteNonQuery()

            cmd = New MySqlCommand("UPDATE gajistaff SET gaji = '" & TextBox4.Text & "' where namastaff = '" & ComboBox2.Text & "'", konek)
            cmd.ExecuteNonQuery()
            gaji()
            atur()
        End If
    End Sub

    Private Sub PictureBox3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox3.Click
        Me.Close()
    End Sub

    Private Sub GAJIPENYIARToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GAJIPENYIARToolStripMenuItem.Click
        Me.Hide()
        rekapgaji.Show()
    End Sub

    Private Sub GAJISTAFFToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GAJISTAFFToolStripMenuItem.Click
        Me.Show()
    End Sub

End Class