﻿Public Class menuKeuangan

    Private Sub PENYIARToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Close()
        statusstaff.show()
    End Sub

    Private Sub KARYAWANToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KARYAWANToolStripMenuItem.Click
        Me.Close()

    End Sub

    Private Sub GAJIPENYIARToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GAJIPENYIARToolStripMenuItem.Click
        Me.Hide()
        rekapgaji.Show()
    End Sub

    Private Sub EDITAKUNToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EDITAKUNToolStripMenuItem1.Click
        Me.Hide()
        Form6.Show()
    End Sub

    Private Sub GAJISTAFFToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GAJISTAFFToolStripMenuItem.Click
        Me.Hide()
        gajistaff.Show()
    End Sub

End Class