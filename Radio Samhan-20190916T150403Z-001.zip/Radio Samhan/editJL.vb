﻿Imports MySql.Data.MySqlClient
Imports System.Data.SqlClient
Imports System.Data

Public Class editJL

    Sub opentable()
        Dim myadapter As New MySqlDataAdapter("select * from jadwal_lembur", konek)
        Dim mydata As New DataTable
        myadapter.Fill(mydata)
        DataGridView1.DataSource = mydata
    End Sub

    Sub apus()
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
    End Sub

    Sub atur()
        Me.DataGridView1.Columns(0).HeaderText = "ID"
        Me.DataGridView1.Columns(1).HeaderText = "HARI SIARAN"
        Me.DataGridView1.Columns(2).HeaderText = "WAKTU SIARAN"
        Me.DataGridView1.Columns(3).HeaderText = "NAMA ACARA"
        Me.DataGridView1.Columns(4).HeaderText = "NAMA PENYIAR"
        Me.DataGridView1.Columns(1).Width = 150
        Me.DataGridView1.Columns(2).Width = 150
        Me.DataGridView1.Columns(3).Width = 130.5
        Me.DataGridView1.Columns(4).Width = 180
        Me.DataGridView1.Columns(0).Width = 50
    End Sub

    Private Sub editJS_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        opentable()
        atur()
        konek()
    End Sub

    Private Sub SIARANToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SIARANToolStripMenuItem.Click
        Me.Show()
        editJS.Show()
    End Sub

    Private Sub LEMBURToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LEMBURToolStripMenuItem.Click
        Me.Show()
    End Sub

    Private Sub PENYIARToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PENYIARToolStripMenuItem1.Click
        Me.Close()
        editpenyiar.Show()
    End Sub

    Private Sub KARYAWANToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KARYAWANToolStripMenuItem.Click
        Me.Close()
        editstaff.Show()
    End Sub

    Private Sub PENYIARToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PENYIARToolStripMenuItem.Click
        Me.Close()
        absenpenyiar.Show()
    End Sub

    Private Sub STAFToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles STAFToolStripMenuItem.Click
        Me.Close()
        absenstaff.Show()
    End Sub


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox1.Text = "" And TextBox2.Text = "" Then
            MsgBox("ISI DATA DENGAN LENGKAP !")
        Else
            Dim cmd As MySqlCommand
            Dim Sqltambahan As String = "INSERT INTO jadwal_lembur(hari,waktu,nama_acara,nama_penyiar)values ('" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox4.Text & "','" & TextBox3.Text & "' )"
            cmd = New MySqlCommand(Sqltambahan, konek)
            cmd.ExecuteNonQuery()
            MsgBox("DATA BERHASIL DITAMBAHKAN")
            opentable()
            apus()
        End If
    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        TextBox1.Text = DataGridView1.Rows(e.RowIndex).Cells(1).Value
        TextBox2.Text = DataGridView1.Rows(e.RowIndex).Cells(2).Value
        TextBox4.Text = DataGridView1.Rows(e.RowIndex).Cells(3).Value
        TextBox3.Text = DataGridView1.Rows(e.RowIndex).Cells(4).Value
        TextBox5.Text = DataGridView1.Rows(e.RowIndex).Cells(0).Value
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim cmd2 As MySqlCommand
        cmd2 = New MySqlCommand("DELETE FROM jadwal_lembur where id= '" & TextBox5.Text & "' ", konek)
        cmd2.ExecuteNonQuery()
        MsgBox("Yakin ingin hapus data?")
        MsgBox("DATA BERHASIL TERHAPUS")
        opentable()
        apus()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        If TextBox3.Text = "" Or TextBox4.Text = "" Then
            MsgBox("DATA BELUM LENGKAP")
        Else
            Dim cmd As MySqlCommand
            cmd = New MySqlCommand(" UPDATE jadwal_lembur SET id= '" & TextBox5.Text & "', hari = '" & TextBox1.Text & "', waktu = '" & TextBox2.Text & "', nama_acara = '" & TextBox4.Text & "', nama_penyiar = '" & TextBox3.Text & "' where id = '" & TextBox5.Text & "'", konek)
            cmd.ExecuteNonQuery()
            MsgBox("Data Berhasil Disimpan")
            opentable()
            apus()
        End If
    End Sub

    Private Sub PictureBox3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox3.Click
        Me.Close()
    End Sub

    Private Sub GAJIPENYIARToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GAJIPENYIARToolStripMenuItem.Click
        Me.Close()
        rekapgaji.Show()
    End Sub

    Private Sub GAJISTAFFToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GAJISTAFFToolStripMenuItem.Click
        Me.Close()
        gajistaff.Show()
    End Sub
End Class